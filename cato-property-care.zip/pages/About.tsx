
import React from 'react';
import { CheckCircle2, Award, Heart, TrendingUp } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Story Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="w-full md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1590650516494-0c8e4a4dd67e?auto=format&fit=crop&q=80&w=1200" 
                alt="Business Owner" 
                className="rounded-[3rem] shadow-2xl"
              />
            </div>
            <div className="w-full md:w-1/2">
              <span className="text-sky-500 font-bold uppercase tracking-widest text-sm">Our Story</span>
              <h2 className="text-4xl md:text-6xl font-black text-slate-900 mt-4 mb-8">The Local Difference.</h2>
              <div className="space-y-6 text-slate-600 text-lg leading-relaxed">
                <p>
                  Cato Property Care started with a simple observation: property owners value quality work, but they cherish reliability even more. As a local owner-operated business, we built this company on the foundation of showing up, doing exactly what we promised, and taking genuine pride in the results.
                </p>
                <p>
                  What began as a single truck and a squeegee has grown into a trusted community brand. We aren't a massive corporate franchise; we're your neighbors. We know the Canadian climate and the specific challenges it poses to your property's exterior.
                </p>
                <p>
                  Our goal is simple: To provide the highest level of care for your property while making the process entirely hassle-free for you. When you see our team at your door, you can trust that your home is in good hands.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
              <Award className="w-12 h-12 text-sky-500 mb-6" />
              <h3 className="text-2xl font-bold mb-4">Quality First</h3>
              <p className="text-slate-500 leading-relaxed">We don't believe in "good enough." If there's a streak, we fix it. If the track isn't perfect, we scrub again.</p>
            </div>
            <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
              <Heart className="w-12 h-12 text-rose-500 mb-6" />
              <h3 className="text-2xl font-bold mb-4">Community Focused</h3>
              <p className="text-slate-500 leading-relaxed">We live where we work. Supporting local initiatives and maintaining the beauty of our towns is part of our DNA.</p>
            </div>
            <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
              <TrendingUp className="w-12 h-12 text-emerald-500 mb-6" />
              <h3 className="text-2xl font-bold mb-4">Growth Mindset</h3>
              <p className="text-slate-500 leading-relaxed">We are constantly training and investing in better technology to provide safer, more efficient services.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
