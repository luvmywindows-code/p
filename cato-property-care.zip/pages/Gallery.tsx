
import React from 'react';
import { GALLERY } from '../constants';

const Gallery: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-slate-900 text-white py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl md:text-7xl font-black mb-6">Our Results</h1>
          <p className="text-slate-400 text-xl max-w-2xl mx-auto">
            Take a look at how we transform properties. No filters, just professional quality work.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 gap-24">
          {GALLERY.map((item) => (
            <div key={item.id} className="space-y-8">
              <div className="flex flex-col md:flex-row justify-between items-end border-b border-slate-200 pb-6">
                <h2 className="text-3xl font-black text-slate-900">{item.title}</h2>
                <span className="text-slate-500 font-semibold">Residential Property</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="relative group overflow-hidden rounded-[2rem] shadow-xl">
                  <img src={item.before} alt="Before" className="w-full h-[400px] object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-6 left-6 bg-red-500 text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">Before</div>
                </div>
                <div className="relative group overflow-hidden rounded-[2rem] shadow-xl">
                  <img src={item.after} alt="After" className="w-full h-[400px] object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-6 left-6 bg-emerald-500 text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">After</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Masonry-style grid for more shots */}
        <div className="mt-24">
           <h2 className="text-3xl font-black text-slate-900 mb-12">More Highlights</h2>
           <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="aspect-square rounded-3xl overflow-hidden shadow-md hover:shadow-xl transition-shadow cursor-pointer">
                  <img 
                    src={`https://picsum.photos/seed/${i + 20}/800/800`} 
                    alt="Gallery item" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform" 
                  />
                </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Gallery;
