
import React from 'react';
import { SERVICES } from '../constants';
import { CheckCircle2, Droplets, Sparkles, Wind } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Header */}
      <div className="bg-slate-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-black text-slate-900 mb-6">Our Services</h1>
          <p className="text-slate-600 max-w-2xl mx-auto text-xl leading-relaxed">
            Professional solutions tailored for your property. We don't just clean; we detail your exterior to perfection.
          </p>
        </div>
      </div>

      {/* Main Services */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 space-y-32">
        {SERVICES.map((service, idx) => (
          <div key={service.id} className={`flex flex-col md:flex-row items-center gap-16 ${idx % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
            <div className="w-full md:w-1/2">
              <div className="relative group">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-[500px] object-cover rounded-[3rem] shadow-2xl transition-transform duration-500 group-hover:scale-[1.02]"
                />
                <div className="absolute -bottom-6 -right-6 bg-sky-500 text-white p-8 rounded-[2rem] shadow-xl">
                  {service.icon}
                </div>
              </div>
            </div>
            <div className="w-full md:w-1/2">
              <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-8">{service.title}</h2>
              <p className="text-slate-600 text-lg leading-relaxed mb-8">
                {service.description}
              </p>
              <ul className="space-y-4 mb-10">
                {['Premium Equipment', 'Eco-friendly Solutions', 'Streak-free Guarantee', 'Careful Around Furniture'].map((item) => (
                  <li key={item} className="flex items-center text-slate-800 font-semibold">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 mr-3" />
                    {item}
                  </li>
                ))}
              </ul>
              <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-slate-800 transition-colors">
                Book This Service
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Future Services */}
      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sky-600 font-bold tracking-widest uppercase text-sm">Coming Soon</span>
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 mt-2 mb-4">Scaling Your Care</h2>
            <p className="text-slate-500">We're expanding to offer full-spectrum exterior property maintenance.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 opacity-75 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4"><Wind className="w-12 h-12 text-slate-100 group-hover:text-sky-50 transition-colors" /></div>
                <h3 className="text-2xl font-bold mb-4">Gutter Cleaning</h3>
                <p className="text-slate-500">Protect your foundation with seasonal debris removal and downspout flushing.</p>
             </div>
             <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 opacity-75 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4"><Droplets className="w-12 h-12 text-slate-100 group-hover:text-sky-50 transition-colors" /></div>
                <h3 className="text-2xl font-bold mb-4">Soft Washing</h3>
                <p className="text-slate-500">Gentle chemical treatment for roofs and delicate siding that kills algae and mold.</p>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
