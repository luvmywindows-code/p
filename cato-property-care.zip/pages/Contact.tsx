
import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Simulate API call
    setTimeout(() => {
      // Logic for submission could go here
    }, 2000);
  };

  return (
    <div className="bg-white min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Info Side */}
          <div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8">Let's Get Your Estimate.</h1>
            <p className="text-slate-500 text-xl leading-relaxed mb-12">
              Tell us a bit about your property, and we'll get back to you with a free, no-obligation quote within 24 hours.
            </p>

            <div className="space-y-8">
              <div className="flex items-center space-x-6 p-6 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="bg-sky-500 p-4 rounded-xl text-white">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-400 uppercase tracking-widest">Call or Text</div>
                  <div className="text-xl font-bold text-slate-900">{CONTACT_INFO.phone}</div>
                </div>
              </div>

              <div className="flex items-center space-x-6 p-6 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="bg-sky-500 p-4 rounded-xl text-white">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-400 uppercase tracking-widest">Email Us</div>
                  <div className="text-xl font-bold text-slate-900">{CONTACT_INFO.email}</div>
                </div>
              </div>

              <div className="flex items-center space-x-6 p-6 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="bg-sky-500 p-4 rounded-xl text-white">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-400 uppercase tracking-widest">Service Area</div>
                  <div className="text-xl font-bold text-slate-900">{CONTACT_INFO.serviceArea}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-white p-8 md:p-12 rounded-[3rem] shadow-2xl border border-slate-100">
            {submitted ? (
              <div className="text-center py-20 animate-in fade-in duration-700">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-100 text-emerald-500 rounded-full mb-8">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Request Received!</h2>
                <p className="text-slate-500 text-lg">
                  Thanks for reaching out. A team member will contact you shortly to finalize your estimate.
                </p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-10 text-sky-500 font-bold hover:underline"
                >
                  Send another request
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Your Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="John Doe" 
                      className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Phone Number</label>
                    <input 
                      required
                      type="tel" 
                      placeholder="555-0123" 
                      className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
                  <input 
                    required
                    type="email" 
                    placeholder="john@example.com" 
                    className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Service Type</label>
                  <select className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all">
                    <option>Window Cleaning</option>
                    <option>Screens & Tracks</option>
                    <option>Pressure Washing</option>
                    <option>Full Exterior Detail</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Project Details</label>
                  <textarea 
                    rows={4}
                    placeholder="Describe your property (Approx. number of windows, stories, specific needs...)" 
                    className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-slate-900 text-white py-5 rounded-2xl font-bold text-xl hover:bg-slate-800 transition-all flex items-center justify-center shadow-xl shadow-slate-200"
                >
                  Request My Quote
                  <Send className="ml-3 w-5 h-5" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
