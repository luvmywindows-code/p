
import React, { useState } from 'react';
import { ArrowRight, Phone, Star, Zap, CheckCircle, Shield, Award, Quote } from 'lucide-react';
import { Page } from '../types';
import { SERVICES, TESTIMONIALS, GALLERY, CONTACT_INFO } from '../constants';
import { gemini } from '../services/geminiService';

interface HomeProps {
  onNavigate: (page: Page) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);

  const fetchAdvice = async () => {
    setLoadingAdvice(true);
    const res = await gemini.getQuickCleaningAdvice("Residential Windows", "pre-summer prep");
    setAdvice(res);
    setLoadingAdvice(false);
  };

  return (
    <div className="flex flex-col">
      {/* High-Impact Hero Section - Updated with low-angle professional action visual */}
      <section className="relative h-[90vh] min-h-[750px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 w-full h-full z-0">
          {/* Advanced overlay: heavy bottom vignette for text legibility and "cool" factor */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/30 to-slate-900/40 z-10"></div>
          <img 
            src="https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?auto=format&fit=crop&q=80&w=2400" 
            className="w-full h-full object-cover object-[center_bottom] scale-105 animate-slow-zoom"
            alt="Professional Window Cleaning - High Reach Action"
          />
        </div>

        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white w-full">
          <div className="inline-flex items-center bg-sky-500 px-6 py-2 rounded-full text-[10px] md:text-xs font-black uppercase tracking-[0.3em] mb-8 animate-in slide-in-from-top duration-1000 shadow-2xl">
            <Award className="w-4 h-4 mr-2" />
            PROFESSIONAL GRADE EXTERIOR CARE
          </div>
          
          <h1 className="text-6xl md:text-[11rem] font-black leading-[0.8] tracking-tighter mb-8 text-shadow drop-shadow-2xl animate-in zoom-in duration-700">
            STRATEGIC <br />
            <span className="text-sky-400">CLARITY.</span>
          </h1>
          <p className="text-xl md:text-4xl font-bold max-w-3xl mx-auto mb-12 text-slate-100 text-shadow drop-shadow-lg leading-tight">
            High-Performance Window Cleaning <br className="hidden md:block" />
            Built On Reliability & Pride.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <button 
              onClick={() => onNavigate('contact')}
              className="group bg-sky-500 text-white px-14 py-6 rounded-2xl font-black text-2xl hover:bg-white hover:text-slate-900 transition-all transform hover:scale-105 shadow-2xl flex items-center animate-pulse-soft"
            >
              GET A FREE QUOTE
              <ArrowRight className="ml-3 w-7 h-7 group-hover:translate-x-2 transition-transform" />
            </button>
            <a 
              href={`tel:${CONTACT_INFO.phone}`}
              className="bg-white/10 backdrop-blur-md border-2 border-white/30 text-white px-14 py-6 rounded-2xl font-black text-2xl hover:bg-white/20 transition-all flex items-center shadow-xl"
            >
              <Phone className="mr-3 w-7 h-7" />
              {CONTACT_INFO.phone}
            </a>
          </div>
        </div>
      </section>

      {/* Social Proof Trust Bar */}
      <section className="relative z-30 -mt-16 mx-4 md:mx-auto max-w-6xl">
        <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden py-14 px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-12">
            <div className="flex flex-col items-center text-center">
              <span className="text-5xl font-black text-slate-900">100%</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Satisfaction Guaranteed</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex text-sky-500 mb-2">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Top Local Rated</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-sky-50 p-4 rounded-3xl mb-2">
                <Shield className="w-8 h-8 text-sky-600" />
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fully Insured</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-emerald-50 p-4 rounded-3xl mb-2">
                <CheckCircle className="w-8 h-8 text-emerald-600" />
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Eco-Detailing</span>
            </div>
          </div>
        </div>
      </section>

      {/* Results / Photo Gallery Section */}
      <section className="py-32 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-24">
            <h2 className="text-5xl md:text-8xl font-black text-slate-900 tracking-tighter mb-6 uppercase leading-none">
              SEE THE <span className="text-sky-500">IMPACT.</span>
            </h2>
            <p className="text-slate-500 text-xl font-medium max-w-2xl mx-auto italic">"Clear windows change the way you see your home."</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
            {GALLERY.slice(0, 2).map((item) => (
              <div key={item.id} className="space-y-8">
                <div className="flex items-center justify-between border-b-4 border-slate-900 pb-4">
                   <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">{item.title}</h3>
                   <div className="w-16 h-1.5 bg-sky-500 rounded-full"></div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="relative group rounded-[3rem] overflow-hidden shadow-2xl border border-slate-100">
                    <img src={item.before} alt="Before" className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-1000" />
                    <div className="absolute top-6 left-6 bg-slate-900 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">BEFORE</div>
                  </div>
                  <div className="relative group rounded-[3rem] overflow-hidden shadow-2xl border-2 border-sky-400">
                    <img src={item.after} alt="After" className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-1000" />
                    <div className="absolute top-6 left-6 bg-sky-500 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">AFTER</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-20 text-center">
             <button 
              onClick={() => onNavigate('gallery')}
              className="group inline-flex items-center bg-slate-900 text-white px-12 py-6 rounded-[2rem] font-black uppercase tracking-widest hover:bg-sky-500 transition-all shadow-2xl text-lg"
             >
               Explore All Results <ArrowRight className="ml-3 w-7 h-7 group-hover:translate-x-3 transition-transform" />
             </button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-32 bg-slate-900 text-white relative">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col md:flex-row items-end justify-between mb-24 gap-12">
             <div className="text-left">
               <h2 className="text-6xl md:text-9xl font-black leading-[0.8] tracking-tighter uppercase mb-6">
                 REAL <br />
                 <span className="text-sky-400">TRUST.</span>
               </h2>
               <div className="w-32 h-3 bg-sky-500 rounded-full"></div>
             </div>
             <div className="flex items-center bg-white/5 backdrop-blur-3xl p-12 rounded-[4rem] border border-white/10 shadow-3xl">
                <div className="mr-10">
                   <div className="flex text-yellow-400 mb-2">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-8 h-8 fill-current" />)}
                  </div>
                  <p className="font-black text-4xl uppercase tracking-tighter">4.9 / 5.0</p>
                </div>
                <p className="text-slate-400 font-bold text-sm uppercase tracking-widest leading-relaxed border-l border-white/10 pl-10">
                  Voted #1 <br />
                  Local Service <br />
                  Provider
                </p>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {TESTIMONIALS.map((testimonial) => (
              <div key={testimonial.id} className="bg-white/5 border border-white/10 p-16 rounded-[4rem] relative group hover:bg-white/10 transition-all duration-700 hover:-translate-y-4">
                <Quote className="absolute top-12 right-12 w-20 h-20 text-sky-500/5 group-hover:text-sky-500/20 transition-colors" />
                <div className="flex text-sky-400 mb-10">
                  {[...Array(testimonial.rating)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
                </div>
                <p className="text-2xl font-medium text-slate-200 leading-relaxed mb-12 italic">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center gap-6">
                  <div className="w-14 h-1.5 bg-sky-500 rounded-full"></div>
                  <div>
                    <p className="text-2xl font-black uppercase tracking-tight">{testimonial.name}</p>
                    <p className="text-sky-500 font-bold text-xs uppercase tracking-[0.3em]">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-24">
            <h2 className="text-5xl md:text-8xl font-black text-slate-900 tracking-tighter mb-6 uppercase leading-none">
              ELITE <span className="text-sky-500">SERVICES.</span>
            </h2>
            <div className="w-24 h-3 bg-sky-500 mx-auto rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {SERVICES.map((service) => (
              <div 
                key={service.id}
                className="group bg-white rounded-[4rem] p-16 hover:bg-slate-900 hover:text-white transition-all duration-700 shadow-xl hover:shadow-2xl cursor-pointer border border-slate-100 flex flex-col justify-between"
                onClick={() => onNavigate('services')}
              >
                <div>
                  <div className="bg-sky-500 text-white w-24 h-24 rounded-3xl flex items-center justify-center mb-12 shadow-xl group-hover:scale-110 transition-transform duration-500 group-hover:bg-white group-hover:text-slate-900">
                    <div className="scale-[1.5]">{service.icon}</div>
                  </div>
                  <h3 className="text-4xl font-black mb-8 uppercase tracking-tighter leading-none">{service.title}</h3>
                  <p className="text-slate-500 group-hover:text-slate-400 leading-relaxed mb-12 text-xl font-medium">
                    {service.description}
                  </p>
                </div>
                <div className="flex items-center font-black text-sky-500 group-hover:text-white uppercase tracking-widest text-sm">
                  View Detail <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-3 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Advisor Section */}
      <section className="py-32 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-[5rem] p-20 text-white relative overflow-hidden group shadow-3xl">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-sky-500/10 rounded-full blur-[120px] group-hover:bg-sky-500/30 transition-all duration-1000"></div>
            <div className="relative z-10">
              <div className="flex items-center space-x-6 mb-12">
                <div className="bg-sky-500/20 p-6 rounded-[2rem]">
                  <Zap className="w-14 h-14 text-sky-400 animate-pulse" />
                </div>
                <h3 className="text-4xl font-black tracking-tighter uppercase">CATO AI INTELLIGENCE</h3>
              </div>
              <p className="text-slate-300 mb-14 text-3xl font-medium italic leading-relaxed">
                "Not sure how many storeys or what equipment is needed? Ask our AI for a professional project evaluation."
              </p>
              <div className="flex flex-col sm:flex-row gap-8">
                <button 
                  onClick={fetchAdvice}
                  className="bg-sky-500 text-white px-14 py-8 rounded-3xl font-black uppercase tracking-widest hover:bg-white hover:text-slate-900 transition-all shadow-2xl text-xl"
                >
                  {loadingAdvice ? "Evaluating Project..." : "Analyze My Project"}
                </button>
              </div>
              {advice && (
                <div className="mt-14 p-12 bg-white/5 border border-white/10 rounded-[3rem] text-slate-200 animate-in fade-in slide-in-from-top-8 duration-700 text-2xl leading-relaxed backdrop-blur-md">
                  <p className="whitespace-pre-line">{advice}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Aggressive Conversion CTA */}
      <section className="py-48 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[radial-gradient(#38bdf8_3px,transparent_3px)] [background-size:80px_80px]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h2 className="text-7xl md:text-[13rem] font-black mb-20 leading-[0.8] tracking-tighter uppercase">
              THE BRIGHT <br />
              <span className="text-sky-400">CHOICE.</span>
            </h2>
            <div className="flex flex-col md:flex-row items-center justify-center gap-16">
               <button 
                onClick={() => onNavigate('contact')}
                className="bg-white text-slate-900 px-24 py-12 rounded-[3rem] font-black text-5xl hover:bg-sky-500 hover:text-white transition-all shadow-3xl transform hover:scale-105 active:scale-95"
              >
                BOOK NOW
              </button>
              <div className="text-center md:text-left border-l-4 border-sky-500 pl-16">
                <p className="text-slate-400 font-black uppercase tracking-[0.4em] text-sm mb-3">Priority Support</p>
                <p className="text-6xl font-black text-white hover:text-sky-400 transition-colors cursor-pointer">{CONTACT_INFO.phone}</p>
              </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
