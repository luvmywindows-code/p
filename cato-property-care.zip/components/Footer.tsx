
import React from 'react';
import { Droplets, Phone, Mail, Instagram, Facebook } from 'lucide-react';
import { CONTACT_INFO } from '../constants';
import { Page } from '../types';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center text-white mb-6">
              <Droplets className="w-8 h-8 text-sky-400 mr-2" />
              <span className="text-xl font-bold tracking-tight">CATO PROPERTY CARE</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Local, reliable, and professional property maintenance services. We take pride in making your home or business shine.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><button onClick={() => onNavigate('home')} className="hover:text-sky-400 transition-colors">Home</button></li>
              <li><button onClick={() => onNavigate('services')} className="hover:text-sky-400 transition-colors">Our Services</button></li>
              <li><button onClick={() => onNavigate('gallery')} className="hover:text-sky-400 transition-colors">Results Gallery</button></li>
              <li><button onClick={() => onNavigate('about')} className="hover:text-sky-400 transition-colors">About Us</button></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold mb-6">Services</h4>
            <ul className="space-y-4 text-sm">
              <li className="text-slate-400">Window Cleaning</li>
              <li className="text-slate-400">Screen & Track Cleaning</li>
              <li className="text-slate-400">Pressure Washing</li>
              <li className="text-slate-400">Exterior Detailing</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold mb-6">Get In Touch</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-3 text-sky-400" />
                <span>{CONTACT_INFO.phone}</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-4 h-4 mr-3 text-sky-400" />
                <span>{CONTACT_INFO.email}</span>
              </li>
              <li className="flex items-start">
                <span className="text-sky-400 font-bold mr-3">@</span>
                <span>{CONTACT_INFO.serviceArea}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500">
          <p>&copy; {new Date().getFullYear()} Cato Property Care. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-slate-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-slate-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
