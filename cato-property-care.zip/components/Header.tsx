
import React, { useState } from 'react';
import { Menu, X, Droplets, Phone } from 'lucide-react';
import { Page } from '../types';
import { CONTACT_INFO } from '../constants';

interface HeaderProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems: { label: string; value: Page }[] = [
    { label: 'Services', value: 'services' },
    { label: 'Results', value: 'gallery' },
    { label: 'About', value: 'about' },
    { label: 'Contact', value: 'contact' },
  ];

  const handleNavClick = (page: Page) => {
    onNavigate(page);
    setIsOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-24">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer group"
            onClick={() => handleNavClick('home')}
          >
            <div className="bg-slate-900 p-2.5 rounded-xl text-white mr-3 group-hover:bg-sky-500 transition-colors duration-300">
              <Droplets className="w-7 h-7" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-2xl font-black text-slate-900 tracking-tighter uppercase">CATO</span>
              <span className="text-[10px] font-black text-sky-500 tracking-[0.2em] uppercase">Property Care</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-10 items-center">
            {navItems.map((item) => (
              <button
                key={item.value}
                onClick={() => handleNavClick(item.value)}
                className={`text-sm font-black uppercase tracking-widest transition-colors ${
                  currentPage === item.value 
                    ? 'text-sky-500' 
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
            
            <div className="h-10 w-[1px] bg-slate-200"></div>

            <a 
              href={`tel:${CONTACT_INFO.phone}`}
              className="flex flex-col items-end mr-2 group"
            >
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">Text or Call</span>
              <span className="text-lg font-black text-slate-900 group-hover:text-sky-500 transition-colors leading-none">{CONTACT_INFO.phone}</span>
            </a>

            <button
              onClick={() => handleNavClick('contact')}
              className="bg-sky-500 text-white px-8 py-4 rounded-2xl text-sm font-black uppercase tracking-widest hover:bg-slate-900 transition-all transform hover:scale-105 active:scale-95 shadow-xl shadow-sky-100"
            >
              Get a Quote
            </button>
          </nav>

          {/* Mobile Toggle */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-3 bg-slate-50 rounded-xl text-slate-900 focus:outline-none"
            >
              {isOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 animate-in slide-in-from-top duration-300 shadow-2xl">
          <div className="px-6 pt-6 pb-12 space-y-4">
            {navItems.map((item) => (
              <button
                key={item.value}
                onClick={() => handleNavClick(item.value)}
                className={`block w-full text-left px-4 py-4 text-xl font-black uppercase tracking-tighter rounded-2xl ${
                  currentPage === item.value 
                    ? 'bg-sky-50 text-sky-600' 
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-6 border-t border-slate-100">
               <button
                onClick={() => handleNavClick('contact')}
                className="w-full bg-sky-500 text-white px-4 py-6 rounded-3xl text-center font-black text-2xl uppercase tracking-tighter hover:bg-sky-600 transition-colors shadow-2xl shadow-sky-200"
              >
                Get a Free Quote
              </button>
              <a 
                href={`tel:${CONTACT_INFO.phone}`}
                className="flex items-center justify-center mt-6 text-slate-900 font-black text-xl"
              >
                <Phone className="w-5 h-5 mr-3 text-sky-500" />
                {CONTACT_INFO.phone}
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
