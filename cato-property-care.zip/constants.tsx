
import React from 'react';
import { 
  Sparkles, 
  Droplets, 
  CheckCircle, 
  ShieldCheck, 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Layers,
  Star
} from 'lucide-react';
import { Service, Testimonial, GalleryItem } from './types';

export const COLORS = {
  primary: 'slate-900', // Charcoal
  secondary: 'blue-800', // Deep Blue
  accent: 'sky-500', // Light Blue
  fresh: 'emerald-500', // Fresh Green
};

export const SERVICES: Service[] = [
  {
    id: 'window-cleaning',
    title: 'Professional Window Cleaning',
    description: 'Streak-free interior and exterior cleaning that lets the light in. We use specialized squeegees and eco-friendly solutions.',
    icon: <Sparkles className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'screens-tracks',
    title: 'Screens & Tracks',
    description: 'Detailed detailing for your window frames, screens, and tracks. Removing dust, dirt, and allergens for a total clean.',
    icon: <Layers className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'pressure-washing',
    title: 'Pressure Washing',
    description: 'Renew your siding, driveways, and decks. We remove years of grime and mildew to restore your property’s curb appeal.',
    icon: <Droplets className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1520209759809-a9bcb6cb3241?auto=format&fit=crop&q=80&w=800'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Jenkins',
    location: 'North Vancouver',
    text: "Cato Property Care is hands down the best service I've used. My windows haven't looked this good since the day we moved in. Fast, polite, and zero streaks!",
    rating: 5
  },
  {
    id: '2',
    name: 'Mark Thompson',
    location: 'Oakville',
    text: "Reliability is hard to find in this industry, but these guys nailed it. They showed up exactly when they said they would and even cleaned the tracks without me asking.",
    rating: 5
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    location: 'Toronto West',
    text: "Highly professional. I manage three properties and Cato is my go-to for all exterior maintenance. The pressure washing made our stone patio look brand new.",
    rating: 5
  }
];

export const TRUST_SIGNALS = [
  { text: 'Fully Insured & WCB Covered', icon: <ShieldCheck className="w-5 h-5" /> },
  { text: '100% Satisfaction Guaranteed', icon: <Star className="w-5 h-5" /> },
  { text: 'Proudly Local & Canadian', icon: <MapPin className="w-5 h-5" /> },
  { text: 'Free On-Site Estimates', icon: <Clock className="w-5 h-5" /> }
];

export const GALLERY: GalleryItem[] = [
  {
    id: '1',
    title: 'Residential Masterpiece',
    before: 'https://images.unsplash.com/photo-1597047084897-51e81819a499?auto=format&fit=crop&q=80&w=600&h=400',
    after: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600&h=400',
  },
  {
    id: '2',
    title: 'Commercial Storefront',
    before: 'https://images.unsplash.com/photo-1563298723-dcfebaa392e3?auto=format&fit=crop&q=80&w=600&h=400',
    after: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&q=80&w=600&h=400',
  }
];

export const CONTACT_INFO = {
  phone: '1-800-555-CATO',
  email: 'hello@catopropertycare.ca',
  serviceArea: 'Canada-based (Proudly serving local communities)'
};
