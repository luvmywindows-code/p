// Added React import to provide access to the React namespace for types like ReactNode
import React from 'react';

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  text: string;
  rating: number;
}

export interface GalleryItem {
  id: string;
  before: string;
  after: string;
  title: string;
}

export type Page = 'home' | 'services' | 'about' | 'gallery' | 'contact';