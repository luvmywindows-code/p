import { GoogleGenAI } from "@google/genai";

// Service class for managing Gemini API interactions, following latest @google/genai best practices
export class GeminiService {
  async getQuickCleaningAdvice(serviceType: string, urgency: string): Promise<string> {
    try {
      // Initializing inside the method to ensure we use the latest environment configuration and follow best practices
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am looking for quick window cleaning or property care advice for a ${serviceType} project that is ${urgency}. As Cato Property Care, provide 3 professional tips and explain why professional service is better for this scenario. Keep it concise, professional, and friendly.`,
        config: {
          systemInstruction: "You are the AI assistant for Cato Property Care, a Canadian property maintenance company. You are professional, local, and take pride in quality work.",
        },
      });

      // Accessing .text as a property, which is the correct way to extract output in the current SDK version
      return response.text || "I'm currently cleaning some windows and can't chat! Please contact us directly for an estimate.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Unable to get advice right now. Please reach out to our team!";
    }
  }
}

export const gemini = new GeminiService();